
-- --------------------------------------------------------

--
-- Table structure for table `awards`
--

CREATE TABLE `awards` (
  `id_award` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `icon_class` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `awards`
--

INSERT INTO `awards` (`id_award`, `image_path`, `title`, `description`, `icon_class`) VALUES
(1, 'images/portfolio/github.jpg', '1st Winner', 'UI/UX Design on GITHUB 2024', 'fa fa-trophy'),
(2, 'images/portfolio/poster.jpg', '2nd Winner', 'Poster Competition On Jayaverse 2024', 'fa fa-medal'),
(3, 'images/portfolio/uiux.jpg', '3rd Winner', 'UI/UX Mobile Design Competition On Euformatika-23', 'fa fa-award');
