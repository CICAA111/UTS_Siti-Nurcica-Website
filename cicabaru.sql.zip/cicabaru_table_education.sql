
-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE `education` (
  `id_education` int(11) NOT NULL,
  `start_year` year(4) NOT NULL,
  `end_year` year(4) DEFAULT NULL,
  `institution` varchar(255) NOT NULL,
  `degree` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `education`
--

INSERT INTO `education` (`id_education`, `start_year`, `end_year`, `institution`, `degree`, `description`) VALUES
(1, '2023', NULL, 'Universitas Pembangunan Jaya', 'Bachelor\'s Degree in Informatics', 'Siti Nurcica is currently pursuing a Bachelor\'s degree in Informatics at Universitas Pembangunan Jaya, now in the third semester. Actively involved in various competitions and projects, particularly in the fields of UI/UX design and technology, several awards have been achieved to date.'),
(2, '2020', '2023', 'SMAN 2 CIANJUR', 'Natural Science Track', 'Siti Nurcica attended SMAN 2 Cianjur, focusing on the Natural Science track. This background in natural sciences provided a strong foundation in subjects such as mathematics, biology, chemistry, and physics, which later supported further studies in technology and informatics at the university level.'),
(3, '2017', '2020', 'SMPN 1 WARUNGKONDANG', 'Junior High School Education', 'Siti Nurcica attended SMPN 1 Warungkondang for junior high school education. This period helped in building fundamental knowledge and skills across various subjects, forming the basis for future academic and personal growth.');
