
-- --------------------------------------------------------

--
-- Table structure for table `personal_info`
--

CREATE TABLE `personal_info` (
  `id_info` int(11) NOT NULL,
  `attribute_name` varchar(50) NOT NULL,
  `attribute_value` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `personal_info`
--

INSERT INTO `personal_info` (`id_info`, `attribute_name`, `attribute_value`) VALUES
(1, 'Birthday', 'Oct 5 2005'),
(2, 'Age', '19'),
(3, 'Website', 'www.portpolio.com'),
(4, 'Email', 'cicaluci5@gmail.com'),
(5, 'Degree', 'CS'),
(6, 'Phone', '+62 8128 0554 67'),
(7, 'City', 'Indonesia'),
(8, 'Freelance', 'Available');
