
-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `id_skill` int(11) NOT NULL,
  `icon_class` varchar(50) NOT NULL,
  `skill_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id_skill`, `icon_class`, `skill_name`) VALUES
(1, 'fa fa-palette', 'UI/UX Design'),
(2, 'fa fa-code', 'Web Development'),
(3, 'fa fa-pencil-alt', 'Graphic Design'),
(4, 'fa fa-cube', 'Prototyping'),
(5, 'fa fa-chart-line', 'Wireframing'),
(6, 'fa fa-search', 'User Research'),
(7, 'fa fa-code', 'HTML/CSS'),
(8, 'fab fa-js', 'JavaScript'),
(9, 'fa fa-comments', 'Yapping');
