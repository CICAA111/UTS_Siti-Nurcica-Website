
-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id_service` int(11) NOT NULL,
  `icon_class` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id_service`, `icon_class`, `title`, `description`) VALUES
(1, 'fa fa-mobile-alt', 'UI/UX Design', 'This involves creating user interfaces (UI) and experiences (UX) that are visually appealing and intuitive.'),
(2, 'fa fa-laptop-code', 'Web Design', 'This refers to the process of creating the layout, visual appearance, and functionality of a website.'),
(3, 'fa fa-palette', 'Poster Design', 'Involves creating eye-catching posters with the right balance of text and graphics.'),
(4, 'fa fa-code', 'Front-End', 'This refers to the coding and development of the parts of a website or app that users interact with directly.'),
(5, 'fa fa-search', 'Pro Stalker', 'Likely a humorous or playful term. It could imply someone skilled at finding information.'),
(6, 'fa fa-bullhorn', 'Yapping Enthusiast', 'Another playful term, possibly referring to someone who enjoys talking or discussing ideas extensively.');
