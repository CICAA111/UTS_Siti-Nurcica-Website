
-- --------------------------------------------------------

--
-- Table structure for table `contact_info`
--

CREATE TABLE `contact_info` (
  `id_contact` int(11) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_info`
--

INSERT INTO `contact_info` (`id_contact`, `icon`, `title`, `value`) VALUES
(1, 'fa fa-phone', 'Call Me On', '+62 8128 0554 67'),
(2, 'fa fa-map-marker-alt', 'Office', 'Indonesia'),
(3, 'fa fa-envelope', 'Email', 'cicaluci5@gmail.com'),
(4, 'fa fa-globe-europe', 'Website', 'www.cica.com');
