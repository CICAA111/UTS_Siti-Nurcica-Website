
-- --------------------------------------------------------

--
-- Table structure for table `experience`
--

CREATE TABLE `experience` (
  `id_experience` int(11) NOT NULL,
  `start_year` year(4) NOT NULL,
  `end_year` year(4) DEFAULT NULL,
  `position` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `experience`
--

INSERT INTO `experience` (`id_experience`, `start_year`, `end_year`, `position`, `company`, `description`) VALUES
(1, '2013', '2015', 'Assistant Manager', 'Okane Store', 'This role involved managing operations in a photocopy shop, which enhanced skills in customer service, team coordination, and handling tasks like editing invitations, calendars, and creating bouquets.'),
(2, '2024', '2024', 'Product Sourcing Intern', 'GAOTek, Manhattan USA', 'Successfully passed the interview and received an offer for an internship at GaoTek, a technology company, where the role focuses on project support and involves design and technical tasks.'),
(3, '2024', '2024', 'Video Editor Intern', 'Cosmeloka', 'Gained experience as a Video Editor Intern at Cosmeloka, a company focused on beauty and cosmetics. In this role, tasks included editing promotional and educational videos related to the brand\'s products.');
