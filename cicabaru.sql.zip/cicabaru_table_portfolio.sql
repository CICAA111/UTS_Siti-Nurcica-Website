
-- --------------------------------------------------------

--
-- Table structure for table `portfolio`
--

CREATE TABLE `portfolio` (
  `id_portfolio` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `portfolio`
--

INSERT INTO `portfolio` (`id_portfolio`, `image_path`, `title`, `description`) VALUES
(1, 'images/portfolio/merah6.jpg', 'Web Design Project', 'This project involved creating a responsive web design for a local business. The main challenge was to create a user-friendly interface that works well on both desktop and mobile devices. I used HTML5, CSS3, and JavaScript to build this website, focusing on performance and accessibility.'),
(2, 'images/portfolio/bugarku.jpg', 'Bugarku Mobile App UI Design', 'For this project, I designed the user interface for a fitness tracking mobile app. The goal was to create an intuitive and visually appealing design that motivates users to stay active. I used Figma for the design process and collaborated closely with the development team to ensure smooth implementation.'),
(3, 'images/portfolio/Projek1.jpg', 'Peluk Mobile App UI Design', 'The Peluk project by Ibu Maya is an initiative focused on the prevention and management of Tuberculosis (TB). The goal of the application is to raise awareness and provide support to individuals affected by TB through practical and technology-driven features.'),
(4, 'images/portfolio/tbshield.jpg', 'TB Shield Mobile App UI Design', 'The TB Shield project is centered on technology-based solutions to Tuberculosis (TB) prevention and management, but specific details are currently unavailable.'),
(5, 'images/portfolio/jkn.jpg', 'Re-Design Mobile JKN', 'For this project, I redesigned the user interface for the Mobile JKN app. The goal was to create an intuitive and visually appealing design that improves user experience and accessibility. I used Figma for the design process and focused on enhancing the app\'s functionality and visual appeal.');
