
-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `subject`, `message`, `created_at`) VALUES
(1, 'Kenny Anaga', 'anagakenny24@gmail.com', 'adasdasdasd', 'asdasdsdasda', '2024-10-22 03:56:33'),
(2, 'snickerdoodle', 'asdad@gmail.com', 'asd', 'asdsadsadasdasdasdadasdadadada', '2024-10-22 04:02:09'),
(3, 'CICAK', 'cicaluci5@gmail.com', 'i love u cica', 'aokwowkowkowkow', '2024-10-22 09:28:31'),
(4, 'hanna', 'hanna@gmail.com', '-', 'akoaakaowkokwok', '2024-10-22 11:12:39'),
(5, 'si cantik', 'nasuluden@gmail.com', 'kamu cantik banget', 'aku sayang kmuh', '2024-10-22 17:13:40'),
(6, 'pungkas', 'pungkas@gmail.com', 'pungkas', 'pungkas', '2024-10-23 04:28:17');
