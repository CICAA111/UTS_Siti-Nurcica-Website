
-- --------------------------------------------------------

--
-- Table structure for table `levels`
--

CREATE TABLE `levels` (
  `id_skill` int(11) NOT NULL,
  `skill_name` varchar(50) NOT NULL,
  `skill_percentage` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `levels`
--

INSERT INTO `levels` (`id_skill`, `skill_name`, `skill_percentage`) VALUES
(1, 'JS', 86),
(2, 'PHP', 66),
(3, 'HTML', 96),
(4, 'Bootstrap', 76);
